PLAY_LOG_LEVEL={T}conf_logger_settings_play_log_level{/T}
APPLICATION_LOG_LEVEL={T}conf_logger_settings_application_log_level{/T}
