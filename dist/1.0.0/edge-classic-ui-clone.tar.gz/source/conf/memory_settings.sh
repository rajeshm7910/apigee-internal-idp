min_mem={T}conf_memory_settings_min_mem{/T}
max_mem={T}conf_memory_settings_max_mem{/T}
