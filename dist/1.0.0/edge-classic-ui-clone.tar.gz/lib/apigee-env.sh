############################################################################
# This is an auto-generated file, if you would like to add variables here,
# create package/rpm/template-value.list with name=value before packaging.
############################################################################
export APPLICATION=classic-ui
export APIGEE_PREFIX=edge-
DESCRIPTION=" Application: classic ui Release: 4.18.05"
ITERATION="0.0.0"
LICENSE="Apigee Corp. All rights reserved."
MAINTAINER="Apigee Corporation <build@apigee.com>"
NAME="edge-classic-ui"
RPM_GROUP="apigee"
RPM_USER="apigee"
URL="http://www.apigee.com/docs"
VENDOR="Apigee Corp."
VERSION="4.18.05"
RUN_USER=${RUN_USER:-${RPM_USER}}
RUN_GROUP=${RPM_GROUP}
